# منظومة السيرة والمواظبة - APK كامل WebView

هذه النسخة تحافظ على النموذج المعتمد كاملًا كما هو داخل APK:
- صفحة البداية نفسها.
- كل وظائف السجل والاستيراد والعطل والطباعة.
- الأيقونة الجديدة.
- Pinch Zoom بالأصابع.
- تحريك الصفحة يمين/شمال وفوق/تحت داخل WebView.

## إذا رفعت محتويات المشروع كاملة
GitHub سيرى ملف:
.github/workflows/build-apk.yml

## إذا رفعت ZIP وحده
أنشئ ملفًا في GitHub باسم:
.github/workflows/build.yml

وانسخ محتوى الملف:
BUILD_FROM_ZIP_WORKFLOW_COPY_THIS.yml
