package com.walhero.siramowathaba;

import android.app.Activity;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.content.Intent;
import android.content.Context;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF1E1B4B);
        getWindow().setNavigationBarColor(0xFF1E1B4B);

        FrameLayout container = new FrameLayout(this);

        webView = new WebView(this);
        container.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        Button backButton = new Button(this);
        backButton.setText("رجوع");
        backButton.setTextSize(13);
        backButton.setAllCaps(false);
        backButton.setTextColor(0xFFFFFFFF);
        backButton.setBackgroundColor(0xCC1E1B4B);
        FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(
                dp(82),
                dp(42),
                Gravity.TOP | Gravity.START
        );
        backParams.setMargins(dp(8), dp(8), dp(8), dp(8));
        container.addView(backButton, backParams);

        backButton.setOnClickListener(v -> handleBackButton());

        setContentView(container);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        // Pinch zoom + moving page right/left/up/down.
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        // Smaller initial display so the full page fits better on phone screens, while keeping pinch zoom.
        s.setTextZoom(85);
        webView.setInitialScale(55);
        webView.setHorizontalScrollBarEnabled(true);
        webView.setVerticalScrollBarEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "(function(){"
                        + "var m=document.querySelector('meta[name=viewport]');"
                        + "if(m){m.setAttribute('content','width=1280, initial-scale=0.35, minimum-scale=0.25, maximum-scale=3.0, user-scalable=yes');}"
                        + "document.documentElement.style.overflow='auto';"
                        + "document.body.style.overflow='auto';"
                        + "})()",
                        null
                );
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith("file:") || url.startsWith("data:") || url.startsWith("about:")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                return super.onJsAlert(view, url, message, result);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void handleBackButton() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){"
                + "var closed=false;"
                + "['editCellModal','confirmModal','multiPrintModal','previewModal','personalClassesModal','schoolYearModal','pasteHolidaysModal'].forEach(function(id){"
                + "var el=document.getElementById(id);"
                + "if(el && !el.classList.contains('hidden')){el.classList.add('hidden');closed=true;}"
                + "});"
                + "var sys=document.getElementById('attendanceSystem');"
                + "var login=document.getElementById('loginScreen');"
                + "if(!closed && sys && login && !sys.classList.contains('hidden')){sys.classList.add('hidden');login.classList.remove('hidden');closed=true;}"
                + "closed;"
                + "})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) webView.goBack();
                    else finish();
                }
        );
    }

    @Override
    public void onBackPressed() {
        handleBackButton();
    }
}
