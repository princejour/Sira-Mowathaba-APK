package com.walhero.siramowathaba;

import android.app.Activity;
import android.Manifest;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.provider.Settings;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF1E1B4B);
        getWindow().setNavigationBarColor(0xFF1E1B4B);

        FrameLayout container = new FrameLayout(this);

        webView = new WebView(this);
        container.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        Button backButton = new Button(this);
        backButton.setText("رجوع");
        backButton.setTextSize(13);
        backButton.setAllCaps(false);
        backButton.setTextColor(0xFFFFFFFF);
        backButton.setBackgroundColor(0xCC1E1B4B);
        FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(
                dp(82),
                dp(42),
                Gravity.TOP | Gravity.START
        );
        backParams.setMargins(dp(8), dp(8), dp(8), dp(8));
        container.addView(backButton, backParams);

        backButton.setOnClickListener(v -> handleBackButton());

        setContentView(container);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        // Pinch zoom + moving page right/left/up/down.
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        // Keep the login/start page at its original display, while allowing pinch zoom.
        s.setTextZoom(100);
        webView.setInitialScale(85);
        webView.setHorizontalScrollBarEnabled(true);
        webView.setVerticalScrollBarEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "(function(){"
                        + "var m=document.querySelector('meta[name=viewport]');"
                        + "if(m){m.setAttribute('content','width=device-width, initial-scale=1.0, minimum-scale=0.25, maximum-scale=3.0, user-scalable=yes');}"
                        + "document.documentElement.style.overflow='auto';"
                        + "document.body.style.overflow='auto';"
                        + "window.__applyPhoneFit=function(){"
                        + "var login=document.getElementById('loginScreen');"
                        + "var sys=document.getElementById('attendanceSystem');"
                        + "if(login){login.style.zoom='';login.style.transform='';login.style.width='';login.style.height='';login.style.marginTop='';login.style.paddingTop='';}"
                        + "if(sys && !sys.classList.contains('hidden')){"
                        + "sys.style.transform='';"
                        + "sys.style.width='max-content';"
                        + "sys.style.minWidth='100vw';"
                        + "sys.style.height='calc(100vh - 58px)';"
                        + "sys.style.maxHeight='calc(100vh - 58px)';"
                        + "sys.style.marginTop='58px';"
                        + "sys.style.overflow='visible';"
                        + "document.body.style.overflowX='auto';"
                        + "document.body.style.overflowY='auto';"
                        + "document.documentElement.style.overflowX='auto';"
                        + "document.documentElement.style.overflowY='auto';"
                        + "}"
                        + "};"
                        + "if(!window.__originalEnterSystem && typeof window.enterSystem==='function'){"
                        + "window.__originalEnterSystem=window.enterSystem;"
                        + "window.enterSystem=function(){window.__originalEnterSystem();setTimeout(window.__applyPhoneFit,60);};"
                        + "}"
                        + "setTimeout(window.__applyPhoneFit,120);"
                        + "})()",
                        null
                );
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith("file:") || url.startsWith("data:") || url.startsWith("about:")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                return super.onJsAlert(view, url, message, result);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void handleBackButton() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){"
                + "var closed=false;"
                + "['editCellModal','confirmModal','multiPrintModal','previewModal','personalClassesModal','schoolYearModal','pasteHolidaysModal'].forEach(function(id){"
                + "var el=document.getElementById(id);"
                + "if(el && !el.classList.contains('hidden')){el.classList.add('hidden');closed=true;}"
                + "});"
                + "var sys=document.getElementById('attendanceSystem');"
                + "var login=document.getElementById('loginScreen');"
                + "if(!closed && sys && login && !sys.classList.contains('hidden')){sys.classList.add('hidden');login.classList.remove('hidden');closed=true;}"
                + "closed;"
                + "})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView.canGoBack()) webView.goBack();
                    else finish();
                }
        );
    }

    @Override
    public void onBackPressed() {
        handleBackButton();
    }
}
