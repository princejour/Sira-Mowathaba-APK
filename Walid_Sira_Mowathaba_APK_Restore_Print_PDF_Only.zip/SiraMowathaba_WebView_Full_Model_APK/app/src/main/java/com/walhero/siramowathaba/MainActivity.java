package com.walhero.siramowathaba;

import android.app.Activity;
import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import android.util.Base64;
import android.content.pm.PackageManager;
import android.provider.Settings;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(0xFF1E1B4B);
        getWindow().setNavigationBarColor(0xFF1E1B4B);

        FrameLayout container = new FrameLayout(this);

        webView = new WebView(this);
        container.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
        ));

        Button backButton = new Button(this);
        backButton.setText("رجوع");
        backButton.setTextSize(13);
        backButton.setAllCaps(false);
        backButton.setTextColor(0xFFFFFFFF);
        backButton.setBackgroundColor(0xCC1E1B4B);
        FrameLayout.LayoutParams backParams = new FrameLayout.LayoutParams(
                dp(82),
                dp(42),
                Gravity.TOP | Gravity.START
        );
        backParams.setMargins(dp(8), dp(8), dp(8), dp(8));
        container.addView(backButton, backParams);

        backButton.setOnClickListener(v -> handleBackButton());

        setContentView(container);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        // Pinch zoom + moving page right/left/up/down.
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);

        // Keep the login/start page at its original display, while allowing pinch zoom.
        s.setTextZoom(100);
        webView.setInitialScale(85);
        webView.setHorizontalScrollBarEnabled(true);
        webView.setVerticalScrollBarEnabled(true);
        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                view.evaluateJavascript(
                        "(function(){"
                        + "var m=document.querySelector('meta[name=viewport]');"
                        + "if(m){m.setAttribute('content','width=device-width, initial-scale=1.0, minimum-scale=0.25, maximum-scale=3.0, user-scalable=yes');}"
                        + "document.documentElement.style.overflow='auto';"
                        + "document.body.style.overflow='auto';"
                        + "window.__applyPhoneFit=function(){"
                        + "var login=document.getElementById('loginScreen');"
                        + "var sys=document.getElementById('attendanceSystem');"
                        + "if(login){login.style.zoom='';login.style.transform='';login.style.width='';login.style.height='';login.style.marginTop='';login.style.paddingTop='';}"
                        + "if(sys && !sys.classList.contains('hidden')){"
                        + "sys.style.transform='';"
                        + "sys.style.width='max-content';"
                        + "sys.style.minWidth='100vw';"
                        + "sys.style.height='calc(100vh - 58px)';"
                        + "sys.style.maxHeight='calc(100vh - 58px)';"
                        + "sys.style.marginTop='58px';"
                        + "sys.style.overflow='visible';"
                        + "document.body.style.overflowX='auto';"
                        + "document.body.style.overflowY='auto';"
                        + "document.documentElement.style.overflowX='auto';"
                        + "document.documentElement.style.overflowY='auto';"
                        + "}"
                        + "};"
                        + "if(!window.__originalEnterSystem && typeof window.enterSystem==='function'){"
                        + "window.__originalEnterSystem=window.enterSystem;"
                        + "window.enterSystem=function(){window.__originalEnterSystem();setTimeout(window.__applyPhoneFit,60);};"
                        + "}"
                        + "setTimeout(window.__applyPhoneFit,120);"
                        + "})()",
                        null
                );

                view.evaluateJavascript(
                        "(function(){"
                        + "window.__nativePrintHtml=function(html){try{AndroidBridge.printHtml(html);return true;}catch(e){return false;}};"
                        + "window.__nativeSaveHtmlPdf=function(html,name){try{AndroidBridge.saveHtmlAsFile(html,name||'سجل_غيابات.html');return true;}catch(e){return false;}};"
                        + "if(!window.__nativePrintPatch){"
                        + "window.__nativePrintPatch=true;"
                        + "var oldOpen=window.open;"
                        + "window.open=function(){"
                        + "var doc='';"
                        + "return {document:{write:function(h){doc+=h;},close:function(){"
                        + "if(doc.indexOf('html2pdf')>-1 || doc.indexOf('pdf_action')>-1){AndroidBridge.saveHtmlAsFile(doc,'سجل_غيابات.html');}"
                        + "else{AndroidBridge.printHtml(doc);}"
                        + "}},focus:function(){}};"
                        + "};"
                        + "}"
                        + "if(typeof window.executeFinalPrint==='function'){var oldP=window.executeFinalPrint;window.executeFinalPrint=function(){try{closePreviewModal();}catch(e){};AndroidBridge.printHtml(getPrintableHTML(activeStudent,document.getElementById('classSelect').value,''));};}"
                        + "if(typeof window.executeFinalPDF==='function'){var oldD=window.executeFinalPDF;window.executeFinalPDF=function(){try{closePreviewModal();}catch(e){};AndroidBridge.saveHtmlAsFile(getPrintableHTML(activeStudent,document.getElementById('classSelect').value,''),'سجل_غيابات.html');};}"
                        + "}"
                        + "})()",
                        null
                );
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri.toString();
                if (url.startsWith("file:") || url.startsWith("data:") || url.startsWith("about:")) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    Intent intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                return super.onJsAlert(view, url, message, result);
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                return super.onConsoleMessage(consoleMessage);
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");

        webView.evaluateJavascript("", null);

        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void handleBackButton() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){try{return (typeof window.appNativeBack==='function' && window.appNativeBack()) ? 'handled' : 'unhandled';}catch(e){return 'unhandled';}})()",
                value -> {
                    if (value != null && value.contains("handled")) return;
                    if (webView.canGoBack()) webView.goBack();
                }
        );
    }

    @Override
    public void onBackPressed() {
        handleBackButton();
    }
    public class AndroidBridge {
        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(() -> {
                try {
                    WebView printWebView = new WebView(MainActivity.this);
                    printWebView.getSettings().setJavaScriptEnabled(true);
                    printWebView.setWebViewClient(new WebViewClient() {
                        @Override
                        public void onPageFinished(WebView view, String url) {
                            view.postDelayed(() -> {
                                try {
                                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                                    if (printManager != null) {
                                        printManager.print("سجل الغيابات", view.createPrintDocumentAdapter("سجل الغيابات"), new PrintAttributes.Builder().build());
                                    }
                                } catch (Exception ignored) {}
                            }, 500);
                        }
                    });
                    printWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void saveHtmlAsFile(final String html, final String filename) {
            runOnUiThread(() -> {
                try {
                    File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    if (!dir.exists()) dir.mkdirs();
                    String safe = (filename == null || filename.trim().isEmpty()) ? "سجل_غيابات.html" : filename;
                    if (!safe.endsWith(".html")) safe = safe + ".html";
                    File file = new File(dir, safe);
                    FileOutputStream fos = new FileOutputStream(file);
                    fos.write(html.getBytes("UTF-8"));
                    fos.close();
                    android.widget.Toast.makeText(MainActivity.this, "تم حفظ الملف في التنزيلات: " + safe, android.widget.Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    android.widget.Toast.makeText(MainActivity.this, "تعذر حفظ الملف", android.widget.Toast.LENGTH_LONG).show();
                }
            });
        }
    }

}
